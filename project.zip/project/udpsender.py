from socket import *
import os
import struct
import time

def read_image(image_path, segment_size):
    chunks = []
    with open(image_path, 'rb') as img:
        while True:
            data = img.read(segment_size)
            if not data:
                break
            chunks.append(data)
    return chunks

def send_image(image_path, server_address, segment_size, window_size):
    file_id = 1  # Static file ID for this example
    packet_id = 0
    base = 0

    chunks = read_image(image_path, segment_size)

    with socket(AF_INET, SOCK_DGRAM) as client:
        while base < len(chunks):
            next_seq = base
            while next_seq < min(base + window_size, len(chunks)):
                chunk = chunks[next_seq]
                # Construct the packet
                packet = struct.pack('!HH', next_seq, file_id) + chunk + struct.pack('!H', 0x0000)
                client.sendto(packet, server_address)
                print(f"Sent packet {next_seq}")
                next_seq += 1

            start_time = time.time()
            while True:
                try:
                    client.settimeout(1)  # Set timeout for acknowledgment
                    ack, _ = client.recvfrom(1024)
                    ack_packet_id, _ = struct.unpack('!HH', ack)
                    if ack_packet_id >= base:
                        print(f"Acknowledgment received for packet {ack_packet_id}")
                        base = ack_packet_id + 1  # Move the window base
                        break
                except timeout:
                    print("Timeout occurred, resending window...")
                    break  # Resend the window

                if time.time() - start_time >= 1:  # Adjust timeout value as needed
                    print("Timeout occurred, resending window...")
                    break  # Resend the window

        # Send an empty packet to signal completion
        client.sendto(struct.pack('!HHH', next_seq, file_id, 0x0000), server_address)
        print("Transmission complete.")

if _name_ == '_main_':
    server_address = (gethostname(), 8888)
    image_path = r'C:\Users\DELL\Pictures\Screenshots\Screenshot (273).png'
    segment_size = 1024  # Define your preferred segment size here
    window_size = 4  # Define your preferred window size here
    send_image(image_path, server_address, segment_size, window_size)
