import socket
import struct
from random import uniform
from time import sleep

def receive_image(server_socket):
    try:
        expected_packet_id = 0
        while True:
            packet, addr = server_socket.recvfrom(4096)
            if not packet:
                break
            # Unpack the packet header and trailer
            header = packet[:4]
            trailer = packet[-2:]
            data = packet[4:-2]

            packet_id, file_id = struct.unpack('!HH', header)
            trailer = struct.unpack('!H', trailer)

            if trailer[0] != 0x0000:
                print("Packet corruption detected.")
                continue

            # Simulate packet loss
            if uniform(0, 1) < 0.15:  # Simulated loss rate between 5% and 15%
                print(f"Packet {packet_id} lost.")
                continue

            if packet_id == expected_packet_id:
                # Write to file (omitted here for brevity)
                print(f"Received packet {packet_id} from file {file_id}")

                # Send acknowledgment
                server_socket.sendto(struct.pack('!HH', packet_id, file_id), addr)

                expected_packet_id += 1

            elif packet_id < expected_packet_id:
                # Duplicate packet received, send acknowledgment again
                print(f"Duplicate packet {packet_id} received.")
                server_socket.sendto(struct.pack('!HH', packet_id, file_id), addr)

            else:
                # Out of order packet received, ignore
                print(f"Out of order packet {packet_id} received.")

    except KeyboardInterrupt:
        print("Server interrupted by user.")

if _name_ == '_main_':
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind(('', 8888))
        print("Server is listening...")
        receive_image(server)
import socket
import struct
from random import uniform
from time import sleep

def receive_image(server_socket):
    try:
        expected_packet_id = 0
        while True:
            packet, addr = server_socket.recvfrom(4096)
            if not packet:
                break
            # Unpack the packet header and trailer
            header = packet[:4]
            trailer = packet[-2:]
            data = packet[4:-2]

            packet_id, file_id = struct.unpack('!HH', header)
            trailer = struct.unpack('!H', trailer)

            if trailer[0] != 0x0000:
                print("Packet corruption detected.")
                continue

            # Simulate packet loss
            if uniform(0, 1) < 0.15:  # Simulated loss rate between 5% and 15%
                print(f"Packet {packet_id} lost.")
                continue

            if packet_id == expected_packet_id:
                # Write to file (omitted here for brevity)
                print(f"Received packet {packet_id} from file {file_id}")

                # Send acknowledgment
                server_socket.sendto(struct.pack('!HH', packet_id, file_id), addr)

                expected_packet_id += 1

            elif packet_id < expected_packet_id:
                # Duplicate packet received, send acknowledgment again
                print(f"Duplicate packet {packet_id} received.")
                server_socket.sendto(struct.pack('!HH', packet_id, file_id), addr)

            else:
                # Out of order packet received, ignore
                print(f"Out of order packet {packet_id} received.")

    except KeyboardInterrupt:
        print("Server interrupted by user.")

if _name_ == '_main_':
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind(('', 8888))
        print("Server is listening...")
        receive_image(server)
